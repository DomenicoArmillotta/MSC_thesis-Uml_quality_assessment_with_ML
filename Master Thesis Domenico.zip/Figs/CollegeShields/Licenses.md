This file contains licences accompanying the images in this folder.

# King's College's shield

Files:
        Kings.svg

Derivative files:
        Kings.eps
        Kings.pdf

Source:
        Provided by the college / Vectorised by Krishna Kumar

Licence:
        Public domain

# Gonville and Caius College's shield

Files:
        Gonville_and_Caius.jpg
Source:

        Provided by the college

Licence:

        Not specified

# Fitzwilliam College's shield

Files:

        Fitzwilliam.pdf
        Fitzwilliam.eps
        FitzwilliamRed.pdf
        FitzwilliamRed.eps

Source:

        Provided by the college

Licence:

        Not specified



# Queens' College's shield

File:

        Queens.svg

Derivative files:

        Queens.pdf
        Queens.eps

Source:

        http://en.wikipedia.org/wiki/File:Queens%27_College_%28Cambridge%29_shield.svg

Licence:

        Creative Commons Attribution-Share Alike 3.0 Unported



# St. John's College's shield

File:

        StJohns.png

Derivative files:

        StJohns.eps

Source:

        http://en.wikipedia.org/wiki/File:Johns_shield.png

Licence:

        GNU Free Documentation License, Version 1.2 or any later version



# Peterhouse's shield

File:

       Peterhouse.svg

Derivative files:

       Peterhouse.pdf  (rsvg-convert -f pdf -o Peterhouse.pdf Peterhouse.svg)

Source:

       https://en.wikipedia.org/wiki/File:Peterhouse_shield.svg

Licence:

        GNU Free Documentation License, Version 1.2 or any later version or
        Creative Commons Attribution-Share Alike 3.0 Unported



# Trinity College's shield

File:

        Trinity.svg

Derivative files:

        Trinity.eps
        Trinity.pdf

Source:

        http://en.wikipedia.org/wiki/File:Trinity_College_(Cambridge)_shield.svg

Licence:

        GNU Free Documentation License, Version 1.2 or any later version
